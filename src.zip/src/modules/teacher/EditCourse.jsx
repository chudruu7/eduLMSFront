import { useForm, useFieldArray } from 'react-hook-form';
import { getCourse, updateCourse, deleteCourse } from '../../services/api.js';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext.jsx';
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';

const imageToBase64Compressed = (file, maxW = 1280, maxH = 720, quality = 0.7) =>
  new Promise((resolve, reject) => {
    const img = new Image();
    const reader = new FileReader();
    reader.onload = (e) => {
      img.onload = () => {
        let { width, height } = img;
        const ratio = Math.min(maxW / width, maxH / height, 1);
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(width * ratio);
        canvas.height = Math.round(height * ratio);
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        const data = canvas.toDataURL('image/jpeg', quality);
        resolve(data);
      };
      img.onerror = reject;
      img.src = e.target.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });

export default function EditCourse() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { me } = useAuth();

  const { register, handleSubmit, control, reset } = useForm({
    defaultValues: { title: '', description: '', allowedRoles: ['student','teacher'], bundleLinks: [] },
  });
  const { fields, append, remove } = useFieldArray({ control, name: 'bundleLinks' });

  const [thumbPreview, setThumbPreview] = useState('/Untitled.jpg');

  useEffect(() => {
    const c = getCourse(id);
    if (!c) return navigate('/dashboard');
    if (me.role !== 'admin' && c.teacherId !== me.id) return navigate('/dashboard');

    setThumbPreview(c.thumbnail);
    reset({
      title: c.title,
      description: c.description,
      allowedRoles: c.allowedRoles || ['student','teacher'],
      bundleLinks: c.bundleLinks || [],
    });
  }, [id, me.id, me.role, reset, navigate]);

  const onSave = async (data) => {
    try {
      const updated = {
        id,
        title: data.title,
        description: data.description,
        thumbnail: thumbPreview,
        allowedRoles: Array.isArray(data.allowedRoles) ? data.allowedRoles : [data.allowedRoles].filter(Boolean),
        bundleLinks: (data.bundleLinks || []).map((b, i) => ({ title: (b?.title || '').trim() || `Link ${i + 1}`, url: (b?.url || '').trim() || '#' })),
      };
      updateCourse(updated);
      navigate(`/course/${id}`);
    } catch (e) {
      console.error('Update error', e);
      toast.error('Засвар хадгалахад алдаа гарлаа.');
    }
  };

  const onDelete = () => {
    if (!confirm('Энэ хичээлийг бүр мөсөн устгах уу?')) return;
    const ok = deleteCourse(id);
    if (ok) navigate('/dashboard');
  };

  return (
    <div className="max-w-2xl mx-auto card p-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Хичээл засварлах</h2>
        <button onClick={onDelete} className="btn btn-soft border border-red-400 text-red-300 hover:bg-red-500/10">Устгах</button>
      </div>

      <form onSubmit={handleSubmit(onSave)} className="mt-5 grid gap-4">
        <div>
          <label className="label">Гарчиг</label>
          <input className="input" {...register('title', { required: true })} />
        </div>
        <div>
          <label className="label">Дэлгэрэнгүй тайлбар бичнэ үү</label>
          <textarea className="input" rows={3} {...register('description', { required: true })} />
        </div>
        <div>
          <label className="label">Thumbnail оруулах</label>
          <input type="file" accept="image/*" className="input" onChange={async (e) => {
            const f = e.target.files?.[0];
            if (f) {
              try { const base64 = await imageToBase64Compressed(f, 1280, 720, 0.7); setThumbPreview(base64); }
              catch { toast.error('Зураг уншихад алдаа гарлаа'); }
            }
          }} />
          <div className="mt-3">
            <img src={thumbPreview} alt="preview" className="w-full max-h-52 object-cover rounded-xl border border-ui-border" />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between">
            <label className="label">Хичээлийн линкүүд</label>
            <button type="button" className="btn btn-soft" onClick={() => append({ title: '', url: '' })}>+ Нэмэх</button>
          </div>
          {fields.map((f, idx) => (
            <div key={f.id} className="grid grid-cols-5 gap-3 mt-2">
              <input className="input col-span-2" placeholder="Линк гарчиг" {...register(`bundleLinks.${idx}.title`)} />
              <input className="input col-span-3" placeholder="https://..." {...register(`bundleLinks.${idx}.url`, { required: true })} />
              <div className="col-span-5 flex justify-end">
                <button type="button" className="btn btn-soft" onClick={() => remove(idx)}>Хасах</button>
              </div>
            </div>
          ))}
        </div>

        <div>
          <label className="label">Энэ хичээл харагдах role</label>
          <select multiple className="input h-28" {...register('allowedRoles')}>
            <option value="student">Оюутан</option>
            <option value="teacher">Багш</option>
            {/* <option value="admin">Админ</option> */}
          </select>
          <p className="text-xs text-white/60 mt-1">Windows: Ctrl+Click | macOS: Cmd+Click</p>
        </div>

        <div className="flex items-center justify-end gap-3">
          <button type="button" onClick={() => navigate(-1)} className="btn btn-soft">Буцах</button>
          <button className="btn btn-primary">Хадгалах</button>
        </div>
      </form>
    </div>
  );
}
