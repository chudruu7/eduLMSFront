import { listRegistrationRequests, approveRegistrationRequest, denyRegistrationRequest, listUsers } from '../../services/api.js';
import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';

export default function RegistrationRequests() {
  const [registrations, setRegistrations] = useState([]);

  const loadRegistrations = () => {
    setRegistrations(listRegistrationRequests());
  };

  useEffect(() => {
    loadRegistrations();
  }, []);

  const handleApprove = (id) => {
    try {
      approveRegistrationRequest(id);
      loadRegistrations();
      toast.success('Бүртгэлийн хүсэлтийг зөвшөөрсөн. Хэрэглэгч үүсэв.');
    } catch (e) {
      console.error(e);
      toast.error('Алдаа');
    }
  };

  const handleDeny = (id) => {
    try {
      denyRegistrationRequest(id);
      loadRegistrations();
      toast('Хүсэлтийг татгалзав');
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="card p-4">
      <h3 className="font-semibold text-lg">Бүртгүүлэх хүсэлтүүд</h3>
      {registrations.length === 0 ? (
        <div className="text-white/70 mt-3">Бүртгүүлэх хүсэлт алга байна.</div>
      ) : (
        <ul className="space-y-3 mt-3">
          {registrations.map((r) => (
            <li key={r.id} className="px-4 py-3 rounded-lg border flex justify-between">
              <div>
                <div className="font-medium">{r.name} <span className="text-xs text-white/60">({r.email})</span></div>
                <div className="text-xs text-white/60">Role: <span className="font-mono">{r.role}</span></div>
              </div>
              <div className="flex items-center gap-2">
                {r.status === 'pending' ? (
                  <>
                    <button className="btn btn-sm btn-primary" onClick={() => handleApprove(r.id)}>Зөвшөөрөх</button>
                    <button className="btn btn-sm btn-ghost" onClick={() => handleDeny(r.id)}>Татгалзах</button>
                  </>
                ) : (
                  <div className="text-xs text-white/60">Processed: {r.status}</div>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
