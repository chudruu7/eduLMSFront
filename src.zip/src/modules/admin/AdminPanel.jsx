import CourseList from "./CourseList";
import UserList from "./UserList";
import RegistrationRequests from "./RegistrationRequests";

export default function AdminPanel() {
  return (
    <div className="grid md:grid-cols-3 gap-6">
      <CourseList />
      <UserList />
      <div className="md:col-span-2">
        <RegistrationRequests />
      </div>
    </div>
  );
}