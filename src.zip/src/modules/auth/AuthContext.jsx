import { createContext, useContext, useEffect, useState } from 'react';
import { getMe, loginApi, registerApi, logoutApi, updateUser } from '../../services/api.js';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [me, setMe] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setMe(getMe());
    setLoading(false);
  }, []);

  const login = async (data) => { const user = await loginApi(data); setMe(user); };
  const register = async (data) => { const user = await registerApi(data); setMe(user); };
  const logout = () => { logoutApi(); setMe(null); };
  const updateProfile = (partial) => {
    if (!me) return null;
    const updated = updateUser(me.id, partial);
    setMe(updated);
    return updated;
  };

  return (
    <AuthContext.Provider value={{ me, loading, login, register, logout, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
