import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './modules/ui/Navbar.jsx';
import Login from './modules/auth/Login.jsx';
import Register from './modules/auth/Register.jsx';
import Dashboard from './modules/dashboard/Dashboard.jsx';
import CourseDetail from './modules/course/CourseDetail.jsx';
import Purchase from './modules/payments/Purchase.jsx';
import MyPurchases from './modules/course/MyPurchases.jsx';
import UploadCourse from './modules/teacher/UploadCourse.jsx';
import EditCourse from './modules/teacher/EditCourse.jsx';
import AdminPanel from './modules/admin/AdminPanel.jsx';
import ProtectedRoute from './modules/auth/ProtectedRoute.jsx';
import Profile from './modules/auth/Profile.jsx';
import UserList from './modules/admin/UserList.jsx';
import CourseList from './modules/admin/CourseList.jsx';
import RegistrationRequests from './modules/admin/RegistrationRequests.jsx';

export default function App() {
  return (
    <Router>
      <div className="min-h-screen">
        <Navbar />
        <main className="max-w-7xl mx-auto px-4 py-6">
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/profile" element={<Profile />} />

            <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
            <Route path="/course/:id" element={<ProtectedRoute><CourseDetail /></ProtectedRoute>} />
            <Route path="/purchase/:id" element={<ProtectedRoute><Purchase /></ProtectedRoute>} />
            <Route path="/my-purchases" element={<ProtectedRoute><MyPurchases /></ProtectedRoute>} />

            <Route path="/teacher/upload" element={<ProtectedRoute allowed={["teacher"]}><UploadCourse /></ProtectedRoute>} />
            <Route path="/teacher/edit/:id" element={<ProtectedRoute allowed={["teacher", "admin"]}><EditCourse /></ProtectedRoute>} />

            <Route path="/admin" element={<ProtectedRoute allowed={["admin"]}><AdminPanel /></ProtectedRoute>} />
            <Route path="/admin/users" element={<ProtectedRoute allowed={["admin"]}><UserList /></ProtectedRoute>} />
            <Route path="/admin/courses" element={<ProtectedRoute allowed={["admin"]}><CourseList /></ProtectedRoute>} />
            <Route path="/admin/requests" element={<ProtectedRoute allowed={["admin"]}><RegistrationRequests /></ProtectedRoute>} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}
