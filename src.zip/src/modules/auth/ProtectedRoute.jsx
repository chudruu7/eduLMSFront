import { Navigate } from 'react-router-dom';
import { useAuth } from './AuthContext.jsx';

export default function ProtectedRoute({ children, allowed }) {
  const { me, loading } = useAuth();
  if (loading) return <div className="text-center py-10">Ачаалж байна...</div>;
  if (!me) return <Navigate to="/login" replace />;
  if (allowed && !allowed.includes(me.role)) return <Navigate to="/dashboard" replace />;
  return children;
}
