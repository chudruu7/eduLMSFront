import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext.jsx';
import { useState } from 'react';

export default function Navbar() {
  const { me, logout } = useAuth();
  const navigate = useNavigate();
  const [showRole, setShowRole] = useState(false);

  // Use original (pre-vertical) labels and routes
  const studentItems = [
    { to: '/dashboard', label: 'Үндсэн дэлгэц', icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M13 5v6h6" /></svg>
    )},
    { to: '/exams', label: 'Шалгалт', icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16" /></svg>
    )},
    { to: '/payments', label: 'Төлбөр төлөх', icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 1.343-3 3s1.343 3 3 3 3-1.343 3-3-1.343-3-3-3z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6" /></svg>
    )},
  ];

  const adminItems = [
    { to: '/admin', label: 'Админ панель', icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 1.343-3 3v6h6v-6c0-1.657-1.343-3-3-3z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v2" /></svg>
    )},
    { to: '/admin/users', label: 'Хэрэглэгчид', icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a4 4 0 00-4-4h-1" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20H4v-2a4 4 0 014-4h1" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 12a4 4 0 100-8 4 4 0 000 8z" /></svg>
    )},
    { to: '/admin/registrations', label: 'Бүртгүүлэх хүсэлтүүд', icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6" /></svg>
    )},
  ];

  return (
    <aside className="fixed left-0 top-0 h-full w-56 bg-black/90 text-white shadow-lg">
      <div className="h-full flex flex-col">
        <div className="px-4 py-6 flex items-center gap-3 border-b border-white/5">
          <img src="/logo1.png" alt="logo" className="w-10 h-10 object-cover" />
          <div>
            <div className="font-bold text-lg">eduLMS</div>
            <div className="text-xs text-white/60">Залуу насандаа суралц</div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto mt-4">
          <ul className="space-y-1 px-2">
            {(me?.role === 'admin' ? adminItems : studentItems).map((it) => (
              <li key={it.label}>
                <NavLink to={it.to} className={({isActive}) => `flex items-center gap-3 px-3 py-2 rounded-md hover:bg-white/5 ${isActive ? 'bg-white/5' : ''}`}>
                  <span className="text-white/80">{it.icon}</span>
                  <span className="text-sm">{it.label}</span>
                </NavLink>
              </li>
            ))}
            {/* teacher specific link */}
            {me?.role === 'teacher' && (
              <li>
                <NavLink to="/teacher/upload" className={({isActive}) => `flex items-center gap-3 px-3 py-2 rounded-md hover:bg-white/5 ${isActive ? 'bg-white/5' : ''}`}>
                  <span className="text-white/80">{/* icon */}
                    <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                  </span>
                  <span className="text-sm">Хичээл нэмэх</span>
                </NavLink>
              </li>
            )}
          </ul>
        </nav>

        <div className="px-4 py-4 border-t border-white/5">
          {me ? (
            <div className="flex flex-col gap-2">
              <Link to="/profile" className="flex items-center gap-3">
                {me.avatar ? (
                  <img src={me.avatar} alt="avatar" className="w-9 h-9 rounded-full object-cover" />
                ) : (
                  <div className="w-9 h-9 rounded-full bg-white/6 grid place-items-center">👤</div>
                )}
                <div className="text-sm">
                  <div className="font-medium">{me.name}</div>
                  <div className="text-xs text-white/60">{me.role}</div>
                </div>
              </Link>
              <div className="pt-2">
                <button className="btn btn-red w-full text-sm" onClick={() => { logout(); navigate('/login'); }}>Гарах</button>
              </div>
            </div>
          ) : (
            <NavLink to="/login" className="btn btn-soft w-full text-center">Нэвтрэх</NavLink>
          )}
        </div>
      </div>
    </aside>
  );
}
