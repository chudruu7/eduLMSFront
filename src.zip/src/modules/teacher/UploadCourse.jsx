import { useForm, useFieldArray } from 'react-hook-form';
import { createCourse } from '../../services/api.js';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext.jsx';
import { useState } from 'react';
import toast from 'react-hot-toast';

const normalizeRoles = (val) => {
  if (!val) return ['student', 'teacher'];
  if (Array.isArray(val)) return val.length ? val : ['student', 'teacher'];
  return [val];
};

const imageToBase64Compressed = (file, maxW = 1280, maxH = 720, quality = 0.7) =>
  new Promise((resolve, reject) => {
    const img = new Image();
    const reader = new FileReader();
    reader.onload = (e) => {
      img.onload = () => {
        let { width, height } = img;
        const ratio = Math.min(maxW / width, maxH / height, 1);
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(width * ratio);
        canvas.height = Math.round(height * ratio);
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        const data = canvas.toDataURL('image/jpeg', quality);
        resolve(data);
      };
      img.onerror = reject;
      img.src = e.target.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });

export default function UploadCourse() {
  const { register, handleSubmit, control } = useForm({ defaultValues: { bundleLinks: [] } });
  const navigate = useNavigate();
  const { me } = useAuth();
  const [thumbPreview, setThumbPreview] = useState('/Untitled.jpg');

  const { fields, append, remove } = useFieldArray({ control, name: 'bundleLinks' });

  const onSubmit = async (data) => {
    try {
      const thumbData = data.thumbnail?.[0]
        ? await imageToBase64Compressed(data.thumbnail[0], 1280, 720, 0.7)
        : thumbPreview;

      if (!data.title || !data.description) {
        toast.error('Гарчиг, тайлбар хоёрыг бөглөнө үү');
        return;
      }
      if (!data.bundleLinks || data.bundleLinks.length === 0) {
        toast.error('Дор хаяж 1 линк нэмнэ үү');
        return;
      }

      const course = {
        id: `c${Date.now()}`,
        title: data.title,
        description: data.description,
        thumbnail: thumbData,
        allowedRoles: normalizeRoles(data.allowedRoles),
        teacherId: me.id,
        teacherName: me.name,
        courseType: 'bundle',
        bundleLinks: (data.bundleLinks || []).map((b, i) => ({
          title: (b?.title || '').trim() || `Link ${i + 1}`,
          url: (b?.url || '').trim() || '#',
        })),
      };

      createCourse(course);
      toast.success('Багц хичээл нэмэгдлээ');
      navigate('/dashboard');
    } catch (err) {
      console.error('Upload bundle error:', err);
      toast.error('Хичээл нэмэхэд алдаа гарлаа. Дахин оролдоно уу.');
    }
  };

  return (
    <div className="max-w-2xl mx-auto card p-6">
      <h2 className="text-2xl font-bold">Багц хичээл нэмэх</h2>
      <form onSubmit={handleSubmit(onSubmit)} className="mt-5 grid gap-4">
        <div>
          <label className="label">Гарчиг</label>
          <input className="input" {...register('title', { required: true })} />
        </div>
        <div>
          <label className="label">Тайлбар</label>
          <textarea className="input" rows={3} {...register('description', { required: true })} />
        </div>
        <div>
          <label className="label">Thumbnail зураг</label>
          <input type="file" accept="image/*" className="input" {...register('thumbnail')}
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (f) {
                try { const base64 = await imageToBase64Compressed(f, 1280, 720, 0.7); setThumbPreview(base64); }
                catch { toast.error('Зураг уншихад алдаа гарлаа'); }
              }
            }} />
          <div className="mt-3">
            <img src={thumbPreview} alt="preview" className="w-full max-h-52 object-cover rounded-xl border border-ui-border" />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between">
            <label className="label">Багц линкүүд</label>
            <button type="button" className="btn btn-soft" onClick={() => append({ title: '', url: '' })}>+ Нэмэх</button>
          </div>
          {fields.map((f, idx) => (
            <div key={f.id} className="grid grid-cols-5 gap-3 mt-2">
              <input className="input col-span-2" placeholder="Линк гарчиг" {...register(`bundleLinks.${idx}.title`, { required: false })} />
              <input className="input col-span-3" placeholder="https://..." {...register(`bundleLinks.${idx}.url`, { required: true })} />
              <div className="col-span-5 flex justify-end">
                <button type="button" className="btn btn-soft" onClick={() => remove(idx)}>Хасах</button>
              </div>
            </div>
          ))}
          <p className="text-xs text-white/60 mt-1">YouTube/Vimeo/PDF/веб хуудас зэргийг линк болгон оруулж болно. Дотор нь жижиг preview-ээр харагдана.</p>
        </div>

        <div>
          <label className="label">Энэ хичээл харагдах role</label>
          <select multiple className="input h-28" {...register('allowedRoles')}>
            <option value="student">Оюутан</option>
            <option value="teacher">Багш</option>
            {/* <option value="admin">Админ</option> */}
          </select>
          <p className="text-xs text-white/60 mt-1">Windows: Ctrl+Click | macOS: Cmd+Click</p>
        </div>

        <button className="btn btn-primary">Нэмэх</button>
      </form>
    </div>
  );
}
