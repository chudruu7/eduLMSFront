import { useForm } from 'react-hook-form';
import { useAuth } from './AuthContext.jsx';
import { useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom'; // Link нэмэв

export default function Login() {
  const { register: reg, handleSubmit } = useForm();
  const { login, me } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (me) navigate('/dashboard', { replace: true });
  }, [me, navigate]);

  const onSubmit = async (data) => {
    try {
      await login(data);
      navigate('/dashboard', { replace: true });
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10 card p-6">
      <h2 className="text-2xl font-bold">Нэвтрэх</h2>
      <p className="text-white/70 text-sm mt-1">
        Демо: admin@lms.mn / admin123, teacher@lms.mn / teacher123, student@lms.mn / student123
      </p>

      <form onSubmit={handleSubmit(onSubmit)} className="mt-5 space-y-4">
        <div>
          <label className="label">Имэйл</label>
          <input className="input" type="email" {...reg('email', { required: true })} />
        </div>
        <div>
          <label className="label">Нууц үг</label>
          <input className="input" type="password" {...reg('password', { required: true })} />
        </div>
        <button className="btn btn-primary w-full">Нэвтрэх</button>
      </form>

      <p className="text-white/70 text-sm mt-4 text-center">
        Шинээр бүртгүүлэх бол{" "}
        <Link to="/register" className="text-blue-400 underline">
          энд дарна уу
        </Link>
      </p>
    </div>
  );
}
