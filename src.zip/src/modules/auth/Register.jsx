import { useForm } from 'react-hook-form';
import { useAuth } from './AuthContext.jsx';
import { useNavigate, Link } from 'react-router-dom';
import { useEffect } from 'react';
import { createRegistrationRequest } from '../../services/api.js';
import toast from 'react-hot-toast';

export default function Register() {
  const { register: reg, handleSubmit } = useForm();
  const { me } = useAuth();
  const navigate = useNavigate();

  // Хэрэв хэрэглэгч аль хэдийн нэвтэрсэн бол dashboard руу шилжүүлнэ
  useEffect(() => {
    if (me) navigate('/dashboard', { replace: true });
  }, [me, navigate]);

  // Форм илгээх үед
  const onSubmit = async (data) => {
    try {
      // 🟢 Админ role-ийг хэрэглэгч өөрөө оруулах боломжгүй
      if (data.role === 'admin') {
        alert('Админ эрхийг зөвхөн системийн админ олгодог!');
        return;
      }

  // create registration request instead of directly creating user
  createRegistrationRequest(data);
  toast.success('Бүртгэлийн хүсэлт илгээгдлээ. Админ зөвшөөрсний дараа нэвтрэх боломжтой.');
  navigate('/login', { replace: true });
    } catch (err) {
      console.error('Бүртгэл амжилтгүй:', err);
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10 card p-6">
      <h2 className="text-2xl font-bold">Бүртгүүлэх</h2>
      <p className="text-white/70 text-sm mt-1">
        Доорх талбарыг бөглөж шинэ хэрэглэгч үүсгэнэ үү.
      </p>

      <form onSubmit={handleSubmit(onSubmit)} className="mt-5 space-y-4">
        <div>
          <label className="label">Нэр</label>
          <input className="input" type="text" {...reg('name', { required: true })} />
        </div>

        <div>
          <label className="label">Имэйл</label>
          <input className="input" type="email" {...reg('email', { required: true })} />
        </div>

        <div>
          <label className="label">Нууц үг</label>
          <input className="input" type="password" {...reg('password', { required: true })} />
        </div>

        {/* ✅ Админ role-ийг нуусан сонголт */}
        <div>
          <label className="label">Хэрэглэгчийн төрөл (Role)</label>
          <select className="input" {...reg('role', { required: true })}>
            <option value="">-- Сонгох --</option>
            <option value="student">Сурагч</option>
            <option value="teacher">Багш</option>
            {/* ❌ Админ сонголт оруулахгүй */}
          </select>
        </div>

        <button className="btn btn-primary w-full">Бүртгүүлэх</button>
      </form>

      <p className="text-white/70 text-sm mt-4 text-center">
        Аль хэдийн бүртгэлтэй юу?{" "}
        <Link to="/login" className="text-blue-400 underline">
          Нэвтрэх
        </Link>
      </p>
    </div>
  );
}
