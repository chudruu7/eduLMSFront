import { useAuth } from '../auth/AuthContext.jsx';
import { listCourses } from '../../services/api.js';
import { useLocation } from 'react-router-dom';
import CourseCard from '../course/CourseCard.jsx';

export default function Dashboard() {
  const { me } = useAuth();
  const { search } = useLocation();
  const params = new URLSearchParams(search);
  const q = (params.get('q') || '').trim().toLowerCase();
  const courses = listCourses().filter((c) => {
    const allowed = Array.isArray(c.allowedRoles) ? c.allowedRoles : [c.allowedRoles].filter(Boolean);
    // Determine whether the current user is allowed to see this course
    let visibleByRole = false;
    if (me.role === 'admin') visibleByRole = true;
    else if (me.role === 'teacher' && c.teacherId === me.id) visibleByRole = true;
    else visibleByRole = allowed.includes(me.role);
    if (!visibleByRole) return false;

    // If a search query exists, only include courses that match the query
    if (q) {
      const hay = `${c.title}`.toLowerCase();
      return hay.includes(q);
    }

    return true;
  });

  return (
    <div>
      
      <h2 className="text-2xl font-bold">Программчлалын хэлний хичээлүүд</h2>
      <p className="text-white/70 mt-1">Role: <span className="font-mono">{me.role}</span></p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
        {courses.map((c) => <CourseCard key={c.id} course={c} />)}
        {!courses.length && (
          <div className="text-white/70">Тохирох хичээл олдсонгүй.</div>
        )}
      </div>
    </div>
  );
}
