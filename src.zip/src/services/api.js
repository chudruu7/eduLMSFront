import toast from 'react-hot-toast';

const LS_USERS = 'lms_users';
const LS_ME = 'lms_me';
const LS_COURSES = 'lms_courses';
const LS_PAYMENTS = 'lms_payments';
const LS_REGISTRATIONS = 'lms_registrations';

// const seedIfEmpty = () => {
//   const users = JSON.parse(localStorage.getItem(LS_USERS) || '[]');
//   const courses = JSON.parse(localStorage.getItem(LS_COURSES) || '[]');
//   if (!courses.length) {
//     const sample = [
//       {
//         id: 'c_bundle_1',
//         title: 'Front-end UI багц',
//         description: 'UI дизайны шилдэг нийтлэлүүд ба видео ресурсийн цуглуулга.',
//         thumbnail: '/Untitled.jpg',
//         allowedRoles: ['student', 'teacher', 'admin'],
//         teacherId: 'u2',
//         teacherName: 'Багш Энхтайван',
//         courseType: 'bundle',
//         bundleLinks: [
//           { title: 'React UI Patterns', url: 'https://reactpatterns.com/' },
//           { title: 'Tailwind Docs', url: 'https://tailwindcss.com/docs' },
//           { title: 'Design Principles', url: 'https://lawsofux.com/' },
//         ],
//         purchasedBy: [],
//         price: 19900, // default price in MNT
//       },
//       {
//         id: 'c_bundle_2',
//         title: 'Back-end ба DevOps багц',
//         description: 'API, Docker, CI/CD-ийн гарын авлага, курс, видео нөөцүүд.',
//         thumbnail: '/Untitled.jpg',
//         allowedRoles: ['student', 'teacher'],
//         teacherId: 'u2',
//         teacherName: 'Багш Ариунболд',
//         courseType: 'bundle',
//         bundleLinks: [
//           { title: 'Express Guide', url: 'https://expressjs.com/' },
//           { title: 'Docker Getting Started', url: 'https://docs.docker.com/get-started/' },
//           { title: 'GitHub Actions', url: 'https://docs.github.com/actions' },
//         ],
//         purchasedBy: [],
//         price: 29900,
//       },
//     ];
//     localStorage.setItem(LS_COURSES, JSON.stringify(sample));
//   }
//   if (!users.length) {
//     const demoUsers = [
//       { id: 'u1', name: 'Админ', email: 'admin@lms.mn', role: 'admin', password: 'admin123' },
//       { id: 'u2', name: 'Багш', email: 'teacher@lms.mn', role: 'teacher', password: 'teacher123' },
//       { id: 'u3', name: 'Оюутан', email: 'student@lms.mn', role: 'student', password: 'student123' },
//     ];
//     localStorage.setItem(LS_USERS, JSON.stringify(demoUsers));
//   }
// };
// seedIfEmpty();

export const getMe = () => JSON.parse(localStorage.getItem(LS_ME) || 'null');
export const logoutApi = () => localStorage.removeItem(LS_ME);

export const listUsers = () => JSON.parse(localStorage.getItem(LS_USERS) || '[]');

export const listRegistrationRequests = () => JSON.parse(localStorage.getItem(LS_REGISTRATIONS) || '[]');

export const createRegistrationRequest = ({ name, email, role, password }) => {
  const regs = JSON.parse(localStorage.getItem(LS_REGISTRATIONS) || '[]');
  // if email already exists in users, throw
  const users = listUsers();
  if (users.some((u) => u.email === email)) throw new Error('Exists');
  const req = { id: `r${Date.now()}`, name, email, role, password, status: 'pending', createdAt: Date.now() };
  regs.push(req);
  localStorage.setItem(LS_REGISTRATIONS, JSON.stringify(regs));
  return req;
};

export const approveRegistrationRequest = (reqId) => {
  const regs = JSON.parse(localStorage.getItem(LS_REGISTRATIONS) || '[]');
  const idx = regs.findIndex((r) => r.id === reqId);
  if (idx === -1) throw new Error('RegNotFound');
  regs[idx].status = 'approved';
  regs[idx].processedAt = Date.now();
  localStorage.setItem(LS_REGISTRATIONS, JSON.stringify(regs));

  // create actual user
  const users = listUsers();
  const newUser = { id: `u${Date.now()}`, name: regs[idx].name, email: regs[idx].email, role: regs[idx].role, password: regs[idx].password };
  users.push(newUser);
  localStorage.setItem(LS_USERS, JSON.stringify(users));
  return { req: regs[idx], user: newUser };
};

export const denyRegistrationRequest = (reqId) => {
  const regs = JSON.parse(localStorage.getItem(LS_REGISTRATIONS) || '[]');
  const idx = regs.findIndex((r) => r.id === reqId);
  if (idx === -1) throw new Error('RegNotFound');
  regs[idx].status = 'denied';
  regs[idx].processedAt = Date.now();
  localStorage.setItem(LS_REGISTRATIONS, JSON.stringify(regs));
  return regs[idx];
};

export const updateUserRole = (userId, newRole) => {
  const users = JSON.parse(localStorage.getItem(LS_USERS) || '[]');
  const idx = users.findIndex((u) => u.id === userId);
  if (idx === -1) throw new Error('UserNotFound');
  users[idx] = { ...users[idx], role: newRole };
  localStorage.setItem(LS_USERS, JSON.stringify(users));
  const me = JSON.parse(localStorage.getItem(LS_ME) || 'null');
  if (me && me.id === userId) localStorage.setItem(LS_ME, JSON.stringify(users[idx]));
  return users[idx];
};

export const loginApi = async ({ email, password }) => {
  const users = JSON.parse(localStorage.getItem(LS_USERS) || '[]');
  const found = users.find((u) => u.email === email && u.password === password);
  if (!found) {
    toast.error('Нэвтрэх мэдээлэл буруу байна');
    throw new Error('Invalid');
  }
  localStorage.setItem(LS_ME, JSON.stringify(found));
  toast.success('Амжилттай нэвтэрлээ');
  return found;
};

export const registerApi = async ({ name, email, role, password }) => {
  const users = JSON.parse(localStorage.getItem(LS_USERS) || '[]');
  if (users.some((u) => u.email === email)) {
    toast.error('Ийм имэйлтэй хэрэглэгч бүртгэлтэй байна');
    throw new Error('Exists');
  }
  const newUser = { id: `u${Date.now()}`, name, email, role, password };
  users.push(newUser);
  localStorage.setItem(LS_USERS, JSON.stringify(users));
  localStorage.setItem(LS_ME, JSON.stringify(newUser));
  toast.success('Бүртгэл амжилттай!');
  return newUser;
};

export const listCourses = () => JSON.parse(localStorage.getItem(LS_COURSES) || '[]');
export const getCourse = (id) => listCourses().find((c) => c.id === id);

export const listPaymentRequests = () => JSON.parse(localStorage.getItem(LS_PAYMENTS) || '[]');

export const createPaymentRequest = ({ userId, courseId }) => {
  const reqs = JSON.parse(localStorage.getItem(LS_PAYMENTS) || '[]');
  const req = { id: `p${Date.now()}`, userId, courseId, status: 'pending', createdAt: Date.now() };
  reqs.push(req);
  localStorage.setItem(LS_PAYMENTS, JSON.stringify(reqs));
  return req;
};

const saveCourses = (courses) => localStorage.setItem(LS_COURSES, JSON.stringify(courses));

export const approvePaymentRequest = (paymentId) => {
  const reqs = JSON.parse(localStorage.getItem(LS_PAYMENTS) || '[]');
  const idx = reqs.findIndex((r) => r.id === paymentId);
  if (idx === -1) throw new Error('PaymentNotFound');
  reqs[idx].status = 'approved';
  reqs[idx].processedAt = Date.now();
  localStorage.setItem(LS_PAYMENTS, JSON.stringify(reqs));

  // grant access: add userId to course.purchasedBy
  const courses = JSON.parse(localStorage.getItem(LS_COURSES) || '[]');
  const cidx = courses.findIndex((c) => c.id === reqs[idx].courseId);
  if (cidx !== -1) {
    courses[cidx].purchasedBy = Array.isArray(courses[cidx].purchasedBy) ? courses[cidx].purchasedBy : [];
    if (!courses[cidx].purchasedBy.includes(reqs[idx].userId)) courses[cidx].purchasedBy.push(reqs[idx].userId);
    saveCourses(courses);
  }
  return reqs[idx];
};

export const denyPaymentRequest = (paymentId) => {
  const reqs = JSON.parse(localStorage.getItem(LS_PAYMENTS) || '[]');
  const idx = reqs.findIndex((r) => r.id === paymentId);
  if (idx === -1) throw new Error('PaymentNotFound');
  reqs[idx].status = 'denied';
  reqs[idx].processedAt = Date.now();
  localStorage.setItem(LS_PAYMENTS, JSON.stringify(reqs));
  return reqs[idx];
};

export const createCourse = (course) => {
  try {
    const courses = listCourses();
    courses.push(course);
    localStorage.setItem(LS_COURSES, JSON.stringify(courses));
    toast.success('Хичээл нэмэгдлээ');
    return course;
  } catch (e) {
    if (e?.name === 'QuotaExceededError' || e?.code === 22) {
      toast.error('LocalStorage дүүрсэн байна. Thumbnail-аа жижиг хэмжээгээр оруулна уу.');
    } else {
      toast.error('Хичээл хадгалахад алдаа гарлаа.');
    }
    throw e;
  }
};

export const updateCourse = (partial) => {
  const courses = listCourses();
  const idx = courses.findIndex((c) => c.id === partial.id);
  if (idx === -1) {
    toast.error('Хичээл олдсонгүй');
    throw new Error('CourseNotFound');
  }
  courses[idx] = { ...courses[idx], ...partial };
  localStorage.setItem(LS_COURSES, JSON.stringify(courses));
  toast.success('Хичээл засварлагдлаа');
  return courses[idx];
};

export const deleteCourse = (id) => {
  const courses = listCourses();
  const idx = courses.findIndex((c) => c.id === id);
  if (idx === -1) {
    toast.error('Хичээл олдсонгүй');
    return false;
  }
  courses.splice(idx, 1);
  localStorage.setItem(LS_COURSES, JSON.stringify(courses));
  toast.success('Хичээл устгагдлаа');
  return true;
};

export const updateUser = (userId, partial) => {
  const users = JSON.parse(localStorage.getItem(LS_USERS) || '[]');
  const idx = users.findIndex((u) => u.id === userId);
  if (idx === -1) throw new Error('UserNotFound');
  users[idx] = { ...users[idx], ...partial };
  localStorage.setItem(LS_USERS, JSON.stringify(users));
  const me = JSON.parse(localStorage.getItem(LS_ME) || 'null');
  if (me && me.id === userId) localStorage.setItem(LS_ME, JSON.stringify(users[idx]));
  return users[idx];
};

export const setCoursePrice = (courseId, price) => {
  const courses = listCourses();
  const idx = courses.findIndex((c) => c.id === courseId);
  if (idx === -1) throw new Error('CourseNotFound');
  courses[idx].price = price;
  localStorage.setItem(LS_COURSES, JSON.stringify(courses));
  return courses[idx];
};

export const createPurchase = ({ userId, courseId, method }) => {
  // create a payment record in payments list and immediately approve (simulate)
  const payments = JSON.parse(localStorage.getItem(LS_PAYMENTS) || '[]');
  const p = { id: `pay${Date.now()}`, userId, courseId, method, status: 'pending', createdAt: Date.now() };
  payments.push(p);
  localStorage.setItem(LS_PAYMENTS, JSON.stringify(payments));

  // simulate immediate approval
  const approved = approvePaymentRequest(p.id);
  return approved;
};

export const listUserPurchases = (userId) => {
  const courses = listCourses();
  return courses.filter((c) => Array.isArray(c.purchasedBy) && c.purchasedBy.includes(userId));
};
