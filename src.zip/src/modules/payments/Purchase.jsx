import { useParams, useNavigate } from 'react-router-dom';
import { getCourse, createPurchase } from '../../services/api.js';
import { useAuth } from '../auth/AuthContext.jsx';
import { useState } from 'react';
import toast from 'react-hot-toast';

export default function Purchase() {
  const { id } = useParams();
  const course = getCourse(id);
  const { me } = useAuth();
  const navigate = useNavigate();
  const [method, setMethod] = useState('qpay');

  if (!course) return <div className="text-white/70">Курс олдсонгүй.</div>;

  const handlePay = () => {
    try {
      createPurchase({ userId: me.id, courseId: course.id, method });
      toast.success('Төлбөр амжилттай төлөгдөж, хичээлд хандалт авлаа');
      navigate('/my-purchases');
    } catch (e) {
      console.error(e);
      toast.error('Төлбөр хийхэд алдаа гарлаа');
    }
  };

  return (
    <div className="max-w-2xl mx-auto card p-6">
      <h2 className="text-xl font-semibold">Төлбөр хийх: {course.title}</h2>
      <p className="text-white/70 mt-2">Үнэ: <span className="font-medium">{course.price || 'Тогтоогдоогүй'} ₮</span></p>

      <div className="mt-4">
        <label className="label">Төлбөрийн арга</label>
        <select className="input" value={method} onChange={(e) => setMethod(e.target.value)}>
          <option value="qpay">qpay</option>
          <option value="apple">Apple Pay</option>
          <option value="samsung">Samsung Pay</option>
          <option value="social">Social Pay</option>
        </select>
      </div>

      <div className="mt-6 flex gap-2">
        <button className="btn btn-primary" onClick={handlePay}>Төлбөр төлөх</button>
        <button className="btn btn-ghost" onClick={() => navigate(-1)}>Буцах</button>
      </div>
    </div>
  );
}
