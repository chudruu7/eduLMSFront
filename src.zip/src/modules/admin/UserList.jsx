import { listUsers, updateUserRole } from '../../services/api.js';
import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';

export default function UserList() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    setUsers(listUsers());
  }, []);

  const handleRoleChange = (userId, role) => {
    try {
      const user = users.find((u) => u.id === userId);
      if (!user || user.role === role) return;

      const ok = window.confirm(`${user.name} хэрэглэгчийн role-ыг '${user.role}' → '${role}' болгож өөрчлөх үү?`);
      if (!ok) {
        toast('Өөрчлөлт цуцлагдлаа');
        setUsers(listUsers());
        return;
      }

      updateUserRole(userId, role);
      setUsers(listUsers());
      toast.success('Хэрэглэгчийн role амжилттай өөрчлөгдлөө');
    } catch (e) {
      console.error(e);
      toast.error('Role өөрчлөх явцад алдаа гарлаа');
    }
  };

  return (
    <div className="card p-4">
      <h3 className="font-semibold text-lg">Хэрэглэгчид</h3>
      <ul className="mt-3 space-y-2">
        {users.map((u) => (
          <li key={u.id} className="px-3 py-2 rounded-lg border flex justify-between">
            <div>
              <div className="font-medium">{u.name} <span className="text-xs text-white/60">({u.email})</span></div>
              <div className="text-xs text-white/60">Role: <span className="font-mono">{u.role}</span></div>
            </div>
            <select value={u.role} onChange={(e) => handleRoleChange(u.id, e.target.value)} className="input input-sm">
              <option value="student">student</option>
              <option value="teacher">teacher</option>
              <option value="admin">admin</option>
            </select>
          </li>
        ))}
      </ul>
    </div>
  );
}
