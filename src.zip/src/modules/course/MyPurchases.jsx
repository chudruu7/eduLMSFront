import { useAuth } from '../auth/AuthContext.jsx';
import { listUserPurchases } from '../../services/api.js';
import CourseCard from './CourseCard.jsx';

export default function MyPurchases() {
  const { me } = useAuth();
  const purchased = me ? listUserPurchases(me.id) : [];

  return (
    <div>
      <h2 className="text-2xl font-bold">Миний худалдан авсан хичээлүүд</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
        {purchased.map((c) => <CourseCard key={c.id} course={c} />)}
        {!purchased.length && <div className="text-white/70">Та одоогоор хичээл худалдаж аваагүй байна.</div>}
      </div>
    </div>
  );
}
