import { listCourses, setCoursePrice } from '../../services/api.js';
import AdminPanel from './AdminPanel.jsx';
import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';

export default function CourseList() {
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    setCourses(listCourses());
  }, []);

  const handleSetPrice = (id) => {
    try {
      const value = Number(document.getElementById(`price-${id}`).value || 0);
      setCoursePrice(id, value);
      setCourses(listCourses());
      toast.success('Үнэ амжилттай шинэчлэгдлээ');
    } catch (e) {
      console.error(e);
      toast.error('Алдаа');
    }
  };

  return (
    <div className="card p-4">
      <h3 className="font-semibold text-lg">Курсууд (Үнэ тогтоох)</h3>
      <ul className="mt-3 space-y-3">
        {courses.map((c) => (
          <li key={c.id} className="px-3 py-2 rounded-lg border flex justify-between">
            <div>
              <div className="font-medium">{c.title}</div>
              <div className="text-xs text-white/60">ID: {c.id}</div>
            </div>
            <div className="flex items-center gap-2">
              <input type="number" defaultValue={c.price || 0} className="input input-sm w-28" id={`price-${c.id}`} />
              <button className="btn btn-sm" onClick={() => handleSetPrice(c.id)}>Тогтоох</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}