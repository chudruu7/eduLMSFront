import { useAuth } from './AuthContext.jsx';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import toast from 'react-hot-toast';

export default function Profile() {
  const { me, logout, updateProfile } = useAuth(); // updateProfile нь хэрэглэгчийн мэдээллийг шинэчлэх функц байвал ашиглана
  const navigate = useNavigate();
  const [avatarFile, setAvatarFile] = useState(null);
  const [preview, setPreview] = useState(me?.avatar || null);
  const [name, setName] = useState(me?.name || '');
  const [phone, setPhone] = useState(me?.phone || '');

  // Хэрэв хэрэглэгч нэвтрээгүй бол login руу буцаана
  if (!me) {
    navigate('/login', { replace: true });
    return null;
  }

  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setAvatarFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setPreview(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    // prepare partial
    const doSave = (avatarData) => {
      const partial = { name, phone };
      if (avatarData) partial.avatar = avatarData;
      if (updateProfile) {
        try {
          updateProfile(partial);
          toast.success('Profile амжилттай хадгалагдлаа');
        } catch (e) {
          console.error(e);
          toast.error('Хадгалах үед алдаа гарлаа');
        }
      }
    };

    if (avatarFile) {
      const reader = new FileReader();
      reader.onloadend = () => {
        doSave(reader.result);
        navigate('/dashboard');
      };
      reader.readAsDataURL(avatarFile);
    } else {
      doSave();
      navigate('/dashboard');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10 card p-6 bg-gray-900 text-white rounded-xl shadow-lg">
      <h2 className="text-2xl font-bold mb-4">Хувийн мэдээлэл</h2>
      <p className="text-white/70 text-sm mb-6">
        Та системд {me.role === 'student' ? 'сурагч' : me.role === 'teacher' ? 'багш' : 'админ'} эрхээр нэвтэрсэн байна.
      </p>

      {/* Avatar хэсэг (шинэ UX) */}
      <div className="mb-4 flex flex-col items-center">
        <div className="relative w-28 h-28 rounded-full overflow-hidden mb-2 border-2 border-white/10 shadow-md">
          {preview ? (
            <img src={preview} alt="Avatar" className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-white/6 grid place-items-center text-3xl">👤</div>
          )}

          {/* hidden file input triggered by camera button */}
          <input id="avatarInput" type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />

          <label htmlFor="avatarInput" className="absolute right-0 bottom-0 -translate-y-1/4 translate-x-1/4 bg-ui-bg/80 hover:bg-ui-bg/90 p-2 rounded-full border border-white/10 cursor-pointer">
            <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 text-white/90" viewBox="0 0 20 20" fill="currentColor">
              <path d="M4 5a2 2 0 00-2 2v6a2 2 0 002 2h12a2 2 0 002-2V7a2 2 0 00-2-2h-3.172a2 2 0 01-1.414-.586L9.586 3.172A2 2 0 008.172 2H6a2 2 0 00-2 2v1z" />
            </svg>
          </label>
        </div>

        <div className="flex items-center gap-3">
          {preview && (
            <button className="btn btn-ghost btn-sm" onClick={() => { setPreview(null); setAvatarFile(null); toast('Зураг устгагдлаа'); }}>Зураг устгах</button>
          )}
          <div className="text-xs text-white/60">Зураг оруулахдаа жижиг хэмжээтэй дээр тавина (LocalStorage)</div>
        </div>
      </div>

      <div className="space-y-3">
        <div>
          <label className="label">Нэр</label>
          <input className="input" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <label className="label">Утасны дугаар</label>
          <input className="input" value={phone} onChange={(e) => setPhone(e.target.value)} />
        </div>
        <div>
          <label className="label">Имэйл</label>
          <div className="input bg-gray-800">{me.email}</div>
        </div>
        <div>
          <label className="label">Эрх</label>
          <div className="input bg-gray-800 capitalize">{me.role}</div>
        </div>
      </div>

      <div className="flex gap-3 mt-6">
        <button
          onClick={handleSave}
          className="btn btn-primary flex-1"
        >
          Хадгалах
        </button>
        {/* <button
          onClick={handleLogout}
          className="btn btn-danger flex-1"
        >
          Гарах
        </button> */}
      </div>
    </div>
  );
}
