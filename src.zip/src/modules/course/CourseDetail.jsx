import { useParams, Link, useNavigate } from 'react-router-dom';
import { listCourses, deleteCourse, createPaymentRequest, createPurchase } from '../../services/api.js';
import toast from 'react-hot-toast';
import { useAuth } from '../auth/AuthContext.jsx';
import { useEffect, useState } from 'react';
import EmbedPreview from '../common/EmbedPreview.jsx';

export default function CourseDetail() {
  const { id } = useParams();
  const { me } = useAuth();
  const navigate = useNavigate();
  const course = listCourses().find((c) => c.id === id);
  const [selectedLinkIdx, setSelectedLinkIdx] = useState(0);

  useEffect(() => { setSelectedLinkIdx(0); }, [course?.id]);

  if (!course) return <div className="text-white/70">Хичээл олдсонгүй.</div>;

  const canEdit = me.role === 'admin' || (me.role === 'teacher' && course.teacherId === me.id);
  const hasPurchased = Array.isArray(course.purchasedBy) && course.purchasedBy.includes(me.id);

  const handleDelete = () => {
    if (!window.confirm('Энэ хичээлийг устгах уу? Энэ үйлдлийг буцаах боломжгүй.')) return;
    const ok = deleteCourse(course.id);
    if (ok) navigate('/dashboard');
  };

  return (
    <div className="grid md:grid-cols-3 gap-6">
      <div className="md:col-span-2 card overflow-hidden">
        <div className="p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="text-xl font-semibold">
                {course.title}
                <span className="ml-2 text-xs px-2 py-0.5 rounded bg-indigo-500/20 border border-indigo-400">BUNDLE</span>
              </h2>
              <p className="text-white/70 mt-1">{course.description}</p>
            </div>
            {canEdit && (
              <div className="flex items-center gap-2">
                <Link to={`/teacher/edit/${course.id}`} className="btn btn-soft">Засварлах</Link>
                <button type="button" onClick={handleDelete} className="btn btn-soft border border-red-400 text-red-300 hover:bg-red-500/10">Устгах</button>
              </div>
            )}
          {!canEdit && !hasPurchased && (
            <div className="mt-4">
              <div className="text-sm text-white/70">Үнэ: <span className="font-medium">{course.price ? course.price + ' ₮' : 'Тогтоогдоогүй'}</span></div>
              <div className="mt-2">
                <label className="label text-xs">Төлбөрийн аргууд</label>
                <select className="input input-sm" id="payMethod" defaultValue="qpay">
                  <option value="qpay">qpay</option>
                  <option value="apple">Apple Pay</option>
                  <option value="samsung">Samsung Pay</option>
                  <option value="social">Social Pay</option>
                </select>
              </div>
              <div className="mt-3 flex gap-2">
                <button className="btn btn-primary" onClick={() => {
                  const m = document.getElementById('payMethod').value;
                  try {
                    createPurchase({ userId: me.id, courseId: course.id, method: m });
                    toast.success('Төлбөр амжилттай, хандалт олголоо');
                    // go to purchases page
                    navigate('/dashboard');
                  } catch (e) {
                    console.error(e);
                    toast.error('Төлбөр хийхэд алдаа гарлаа');
                  }
                }}>Төлбөр төлөх</button>
                <button className="btn btn-ghost" onClick={() => {
                  createPaymentRequest({ userId: me.id, courseId: course.id });
                  toast('Төлбөрийн хүсэлт илгээгдлээ. Админ зөвшөөрнө.');
                }}>Хүсэлт илгээх</button>
              </div>
            </div>
          )}
          </div>

          <div className="grid md:grid-cols-3 gap-4 mt-4">
            <div className="md:col-span-1 card p-3">
              <h3 className="font-semibold">Холбоосууд</h3>
              <ul className="mt-3 space-y-2">
                {course.bundleLinks?.map((b, idx) => (
                  <li key={idx} className={`px-3 py-2 rounded-lg border cursor-pointer transition ${idx===selectedLinkIdx ? 'border-indigo-400 bg-indigo-500/10 shadow-glow' : 'border-ui-border hover:border-indigo-400'}`} onClick={() => setSelectedLinkIdx(idx)}>
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate">{b.title || `Link ${idx+1}`}</span>
                      <a href={b.url} target="_blank" rel="noreferrer" className="btn btn-soft text-xs">Очих</a>
                    </div>
                  </li>
                ))}
                {!course.bundleLinks?.length && (
                  <li className="text-white/60 text-sm">Линк нэмэгдээгүй байна.</li>
                )}
              </ul>
            </div>

            <div className="md:col-span-2">
              <EmbedPreview url={course.bundleLinks?.[selectedLinkIdx]?.url} />
            </div>
          </div>
        </div>
      </div>

      <aside className="card p-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Таны мэдээлэл</h3>
          {canEdit && (<span className="text-xs text-white/60">Багш: {course.teacherName}</span>)}
        </div>
        <div className="mt-3 text-xs text-white/60">Төрөл: Багц</div>
        <img src={course.thumbnail} alt="thumb" className="mt-3 w-full rounded-xl border border-ui-border" />
      </aside>
    </div>
  );
}
