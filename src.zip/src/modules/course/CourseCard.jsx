import { Link } from 'react-router-dom';

export default function CourseCard({ course }) {
  return (
    <div className="card overflow-hidden hover:shadow-glow transition group">
      <div className="relative">
        <img
          src={course.thumbnail}
          alt={course.title}
          className="w-full h-44 object-cover group-hover:scale-[1.02] transition"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ui-card/70 to-transparent"></div>
        <div className="absolute top-3 right-3 text-xs px-2 py-0.5 rounded bg-indigo-500/20 border border-indigo-400">BUNDLE</div>
      </div>
      <div className="p-4">
        <h3 className="font-semibold text-lg">{course.title}</h3>
        <p className="text-white/70 text-sm mt-1">{course.description}</p>
        <div className="flex items-center justify-between mt-4">
          <span className="text-xs text-white/60">Багш: {course.teacherName}</span>
          <Link to={`/course/${course.id}`} className="btn btn-primary text-sm">Үзэх</Link>
        </div>
      </div>
    </div>
  );
}
